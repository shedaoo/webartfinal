import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class game {
	
	JFrame window;
	Container con;
	JPanel titleNamePanel, creditNamePanel, startButtonPanel, mainTextPanel, choiceButtonPanel, playerPanel1, playerPanel2;
	JLabel titleNameLabel, creditNameLabel, dayLabel, dayLabelNumber, attemptLabel, attemptLabelNumber;
	Font titleFont = new Font("Arial", Font.BOLD, 100);
	Font buttonFont = new Font("Arial", Font.BOLD, 60);
	Font mainFont = new Font("Arial", Font.PLAIN, 36);
	JButton startButton, choice1, choice2, choice3;
	JTextArea mainTextArea;
	int dayNumber, attemptNumber;
	String weapon, position;
	
	TitleScreenHandler tsHandler = new TitleScreenHandler();
	ChoiceHandler choiceHandler = new ChoiceHandler();

	public static void main(String[] args) {
		new game();
	}

	public game() {
		
		window = new JFrame();
		window.setSize(1200,1000);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.getContentPane().setBackground(Color.black);
		window.setLayout(null);
		con = window.getContentPane();
		
		titleNamePanel = new JPanel();
		titleNamePanel.setBounds(100, 200, 1000, 150);
		titleNamePanel.setBackground(Color.black);
		titleNameLabel = new JLabel("Wake Up");
		titleNameLabel.setForeground(Color.white);
		titleNameLabel.setFont(titleFont);
		creditNamePanel = new JPanel();
		creditNamePanel.setBounds(100, 340, 1000, 50);
		creditNamePanel.setBackground(Color.black);
		creditNameLabel = new JLabel("by nervyCarcass");
		creditNameLabel.setForeground(Color.white);
		creditNameLabel.setFont(mainFont);
		
		startButtonPanel = new JPanel();
		startButtonPanel.setBounds(450, 600, 300, 100);
		startButtonPanel.setBackground(Color.black);
		
		startButton = new JButton("START");
		startButton.setBackground(Color.black);
		startButton.setForeground(Color.white);
		startButton.setFont(buttonFont);
		startButton.setFocusPainted(false);
		startButton.addActionListener(tsHandler);
		
		titleNamePanel.add(titleNameLabel);
		creditNamePanel.add(creditNameLabel);
		startButtonPanel.add(startButton);
		
		con.add(titleNamePanel);
		con.add(creditNamePanel);
		con.add(startButtonPanel);
		
		//window.validate();
		window.setVisible(true);
	}
	
	public void createGameScreen() {
		
		titleNamePanel.setVisible(false);
		creditNamePanel.setVisible(false);
		startButtonPanel.setVisible(false);
		
		mainTextPanel = new JPanel();
		mainTextPanel.setBounds(200, 200, 800, 400);
		mainTextPanel.setBackground(Color.black);
		con.add(mainTextPanel);
		
		mainTextArea = new JTextArea("This is the main text area.");
		mainTextArea.setBounds(200, 200, 800, 400);
		mainTextArea.setBackground(Color.black);
		mainTextArea.setForeground(Color.white);
		mainTextArea.setFont(mainFont);
		mainTextArea.setLineWrap(true);
		mainTextArea.setWrapStyleWord(true);
		mainTextPanel.add(mainTextArea);
		
		choiceButtonPanel = new JPanel();
		choiceButtonPanel.setBounds(200, 650, 800, 300);
		//choiceButtonPanel.setSize(400,300);
		//choiceButtonPanel.setLocation(400, 600);
		choiceButtonPanel.setBackground(Color.black);
		choiceButtonPanel.setLayout(new GridLayout(4,1));
		con.add(choiceButtonPanel);
		
		choice1 = new JButton("Choice 1");
		choice1.setBackground(Color.black);
		choice1.setForeground(Color.white);
		choice1.setFont(mainFont);
		choice1.setFocusPainted(false);
		choice1.addActionListener(choiceHandler);
		choice1.setActionCommand("c1");
		choiceButtonPanel.add(choice1);
		
		choice2 = new JButton("Choice 2");
		choice2.setBackground(Color.black);
		choice2.setForeground(Color.white);
		choice2.setFont(mainFont);
		choice2.setFocusPainted(false);
		choice2.addActionListener(choiceHandler);
		choice2.setActionCommand("c2");
		choiceButtonPanel.add(choice2);
		
		choice3 = new JButton("Choice 3");
		choice3.setBackground(Color.black);
		choice3.setForeground(Color.white);
		choice3.setFont(mainFont);
		choice3.setFocusPainted(false);
		choice3.addActionListener(choiceHandler);
		choice3.setActionCommand("c3");
		choiceButtonPanel.add(choice3);
		
		playerPanel1 = new JPanel();
		playerPanel1.setBounds(200, 50, 200, 100);
		playerPanel1.setBackground(Color.black);
		playerPanel1.setLayout(new GridLayout(1, 4));
		con.add(playerPanel1);
		dayLabel = new JLabel("Day:");
		dayLabel.setFont(mainFont);
		dayLabel.setForeground(Color.white);
		playerPanel1.add(dayLabel);
		dayLabelNumber = new JLabel();
		dayLabelNumber.setFont(mainFont);
		dayLabelNumber.setForeground(Color.white);
		playerPanel1.add(dayLabelNumber);
		playerPanel2 = new JPanel();
		playerPanel2.setBounds(650, 50, 450, 100);
		playerPanel2.setBackground(Color.black);
		playerPanel2.setLayout(new GridLayout(1, 4));
		con.add(playerPanel2);
		attemptLabel = new JLabel("Attempt:");
		attemptLabel.setFont(mainFont);
		attemptLabel.setForeground(Color.white);
		playerPanel2.add(attemptLabel);
		attemptLabelNumber = new JLabel();
		attemptLabelNumber.setFont(mainFont);
		attemptLabelNumber.setForeground(Color.white);
		playerPanel2.add(attemptLabelNumber);
		
		playerSetup();

	}
	
	public void playerSetup() {
		dayNumber = 1;
		attemptNumber = 0;
		dayLabelNumber.setText("" + dayNumber);
		attemptLabelNumber.setText("" + attemptNumber);
		intro1();
	}
	
	public void intro1() {
		position = "intro1";
		mainTextArea.setText("For as long as you can remember, you've always been able to avoid your own death. Whenever you die, you've always woken up to the beginning of the same day, as if your death was just a dream.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void intro2() {
		position = "intro2";
		mainTextArea.setText("You live in a small farming village. There's only one doctor and mortality rate is high. Mothers die in childbirth, chidren go missing in rivers and near ledges, workers get mangled by farming equipment, everyone eventually succumbs to some kind of illness.\n\nYou've grown rather used to the concept of death.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void intro3() {
		position = "intro3";
		mainTextArea.setText("Over the years, you've learned that you can avoid the situations that lead to your death by simply making different choices.\n\nYou can always try again.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void first() {
		position = "first";
		mainTextArea.setText("You are in the forest just at the edge of the village looking for firewood.\n\nThe trail spilts into three paths, one of which you're familiar with, but you've never ventured down the other two.");
		attemptNumber = attemptNumber + 1;
		attemptLabelNumber.setText(""+attemptNumber);
		choice1.setText("Take the path you know");
		choice2.setText("Take the second path");
		choice3.setText("Take the third path");
	}
	
	public void path1() {
		position = "path1";
		mainTextArea.setText("You head down the path you're familiar with and start to gather various sticks to use as firewood. You are almost finished when you hear a branch snap further down the path. You look up and see a wolf-like monster staring intently at you, drooling and foaming at the mouth.");
		choice1.setText("Stay completely still");
		choice2.setText("Play dead");
		choice3.setText("Run");
	}
	
	public void still() {
		position = "still";
		mainTextArea.setText("The monster isn't a dinosaur, stupid. It charges at you and goes for your head. Its powerful jaws crush your skull instantly.\n\nYou are dead.");
		choice1.setText("Wake up");
		choice2.setText("Wake up");
		choice3.setText("Wake up");
	}
	
	public void playdead() {
		position = "playdead";
		mainTextArea.setText("You drop to the ground like a lifeless corpse and lay perfectly still. The monster slowly walks up to you. It sniffs you up and down and starts dragging you by your shirt. Too terrified to move, you let it drag you all the way back to its den, where you are eaten alive by a swarm of monster babies.\n\nYou are dead.");
		choice1.setText("Wake up");
		choice2.setText("Wake up");
		choice3.setText("Wake up");
	}
	
	public void run() {
		position = "run";
		mainTextArea.setText("You turn around and start sprinting as fast as you can, dropping all your sticks. You're too busy running to turn to see behind you, but you can hear the monster right on your heels.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void fork() {
		position = "fork";
		mainTextArea.setText("You run all the way back to where the path had split. It seems you have lost the monster and are safe for now.");
		choice1.setText("Check the first path again");
		choice2.setText("Take the second path");
		choice3.setText("Take the third path");
	}
	
	public void path1Again() {
		position = "path1Again";
		mainTextArea.setText("Why would you do that. You fucking idiot. Obviously the monster kills you. Your plead for death was finally answered.");
		choice1.setText("Wake up");
		choice2.setText("Wake up");
		choice3.setText("Wake up");
	}
	
	public void path2() {
		position = "path2";
		mainTextArea.setText("You head down one of the unknown paths. The dirt trail winds downhill and leads you to a small cave. Obviously you go inside because youre just so gosh dang curious.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void path3() {
		position = "path3";
		mainTextArea.setText("You head down one of the unknown paths. You don't see anything around you other than trees and bushes.\n\nYou see a stick on the ground in front of you (a stick just perfect for poking suspicious objects). It is laying on top of a little pile of leaves.");
		choice1.setText("Keep walking");
		choice2.setText("Inspect the pile");
		choice3.setText("Pick up the stick");
	}
	
	public void keepwalking() {
		position = "keepwalking";
		mainTextArea.setText("You forget about the stick and keep on your way down the path. Suddenly an arrow flies straight into your skull, killing you instantly. A nearby hunter seems to have thought you were some kind of ugly deer. You are dead.");
		choice1.setText("Wake up");
		choice2.setText("wake up");
		choice3.setText("Wake up");
	}
	
	public void inspect() {
		position = "inspect";
		mainTextArea.setText("You cautiously look around the area for any traps. Just an ordinary pile of leaves. Pick up the stick?");
		choice1.setText("No");
		choice2.setText("Yes");
		choice3.setText("Break stick");
	}
	
	public void breakstick() {
		position = "breakstick";
		mainTextArea.setText("You hold the fragile little stick in your all-powerful hands. You are its judge, jury, and executioner. You alone can determine the fate of this one stick that dared cross your path. You mercilessly snap the stick in half and toss its remains on the ground in front of you. It is left to serve as a warning to all other sticks.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void pickup() {
		position = "pickup";
		mainTextArea.setText("You bend down and pick up this nice stick that has been waiting patiently for you. Before you can stand back up, an arrow flies into the tree next to you, missing your head by mere inches. A nearby hunter must have thought you were some kind of ugly deer, but fortunately you are just an ugly human.");
		choice1.setText("Keep walking");
		choice2.setText("Take the arrow");
		choice3.setText("Flip off the hunter");
	}
	
	public void arrow() {
		position = "arrow";
		mainTextArea.setText("You yank the arrow out of the tree. It could be useful later... or maybe not. You take the arrow anyway.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void flipoff() {
		position = "flipoff";
		mainTextArea.setText("Yeah, that'll show him.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void deadend() {
		position = "deadend";
		mainTextArea.setText("Brushing off the minor close call with death, you persist down the rest of the path. Unfortunately the path ends a little ways down from where you found the stick. Nothing left to do but turn around and head back to the fork.");
		choice1.setText("Take the first path");
		choice2.setText("Take the second path ");
		choice3.setText("Take the third path again");
	}
	
	public void path3again() {
		position = "path3again";
		mainTextArea.setText("Why????????????");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void cave1() {
		position = "cave1";
		mainTextArea.setText("\"This is a pretty sweet cave,\" you think to yourself. And it is. This place is just lousy with skeletons. Who knew humans had so many bones? You nearly trip over a dusty skull. \"Now this is just too many bones.\"");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void cave2() {
		position = "cave2";
		mainTextArea.setText("Deeper into the cave you find a pretty swag throne with yet another skeleton just laying there like he owns this cave. ...He probably did though.\n\nHe appears to be clutching a very old bottle of wine in one hand and a silver dagger in the other.");
		choice1.setText("Take the wine");
		choice2.setText("Take the dagger");
		choice3.setText("Steal some bones");
	}
	
	public void wine() {
		position = "wine";
		mainTextArea.setText("The skeleton's hand crumbles to dust as you take it from him. You're too young to drink but there are no laws in this cave, though you don't even like the taste of alcohol.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void dagger() {
		position = "dagger";
		mainTextArea.setText("You attempt to pry the dagger from the skeleton's surprisingly firm grip. You struggle for a few minutes before snapping off some fingers and freeing the dagger.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void steal() {
		position = "steal";
		mainTextArea.setText("For some reason you grab a bunch of the skeleton's bones right out of the chair. You grab way too many bones. Your arms are overflowing with bones. You cant possible hold all these fucking bones.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void skeleton1() {
		position = "skeleton1";
		mainTextArea.setText("The bones begin to rattle and link up together, forming a complete, un-decrepit skeleton standing directly in front of you.\n\nYou are too terrified to move. You and the skeleton face each other waiting for one to make the first move.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void skeleton2() {
		position = "skeleton2";
		mainTextArea.setText("The bones begin to rattle and link up together, forming a complete, un-decrepit skeleton standing directly in front of you.\n\nYou are too terrified to move. You and the skeleton face each other waiting for one to make the first move.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void skeleton3() {
		position = "skeleton3";
		mainTextArea.setText("The bones begin to rattle and link up together, forming a complete, un-decrepit skeleton standing directly in front of you.\n\nYou are too terrified to move. You and the skeleton face each other waiting for one to make the first move.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void fight1() {
		position = "fight1";
		mainTextArea.setText("The skeleton sees you clutching his bottle of wine for dear life. If this guy still had eyebrows they would NOT be happy.\n\nThe skeleton wiggles his fingers in such an evil manner that you cannot imagine what he would be planning to do to you.");
		choice1.setText("Drink");
		choice2.setText("Don't drink");
		choice3.setText("Return the wine");
	}
	
	public void drink() {
		position = "drink";
		mainTextArea.setText("You take a hearty swig of that finely aged cave wine. It tastes terrible and feels like you just drank liquid dirt and sand. You drink as much as you can stomach right in front of the skeleton as he just watches.\n\nHe stares. And you wait for something to happen.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void tension() {
		position = "tension";
		mainTextArea.setText("The skeleton remains still and stares at you for an uncomfortable amount of time. You feel the sweat running down your back from the tension in the air.\n\n...");
		choice1.setText("...");
		choice2.setText("...");
		choice3.setText("...");
	}
	
	public void party() {
		position = "party";
		mainTextArea.setText("The skeleton suddnely exclaims: \"AAAAAAYYYYE lookit this guy ova here!\"\n\nA bunch of other skeletons come out and start slappin you on the back like you're the supreme champion of hoop and stick. Streamers rain down from the ceiling--where did they come from? Everyone's drinking as 90's boyband music plays from deeper inside the cave.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void dontdrink() {
		position = "dontdrink";
		mainTextArea.setText("You decide to not drink the skeleton's wine right in front of him; you lower the bottle.\n\nThe skeleton narrows his eye sockets at you. He calls you a little bitch and snatches the bottle from your bitch-ass hands. He begins to just down the whole thing, and you're just forced to stand there and watch all that wine fall right through all his bones and splatter onto the floor.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void give() {
		position = "give";
		mainTextArea.setText("You shakily offer the wine back to the skeleton. He looks down at the bottle in your trembling hands, then back at you. He accepts it and...drinks it? You watch in awkward confusion as the wine just slips past his jaws and splashes onto the floor. He downs the whole bottle...onto the floor.\n\nThe skeleton somehow burps in your face and calls you a little bitch.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void whatnow() {
		position = "whatnow";
		mainTextArea.setText("You are unsure of what to do next. You continue to stand there in silent confustion and slight shock while the skeleton stabs you with his dagger. Too bad you didn't take that instead.\n\nYou are dead.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void fight2() {
		position = "fight2";
		mainTextArea.setText("The skeleton sees you holding his beloved silver dagger--the one he used to cut living people open. If this guy still had eyebrows they would NOT be happy.\\n\\nThe skeleton wiggles his (remaining) fingers in such an evil manner that you cannot imagine what he would be planning to do to you.");
		choice1.setText("Stab him");
		choice2.setText("Stab yourself");
		choice3.setText("Punch him");
	}
	
	public void stab() {
		position = "stab";
		mainTextArea.setText("You idiot. You absolute buffoon. Why would you even attempt to stab a skeleton? What is that going to do?? You're fuckin' dead kiddo.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void yourself() {
		position = "yourself";
		mainTextArea.setText("You pull the ultimate mind trick on this dumbass skeleton. He can't kill you if you kill yourself first. You lodge that fancy knife right into your ribs. I don't think i need to explain what happens next.\n\nYou are dead.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void punch() {
		position = "punch";
		mainTextArea.setText("You punch that skeleton right in the nose hole, which is still a much better idea than trying to stab him. His fragile, dusty bones shatter onto the floor.\n\nYou loot his cave of all its gold and secrets and head back to your village.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void fight3() {
		position = "fight3";
		mainTextArea.setText("The skeleton bursts out in anger, \"WHAT THE FUCK BRO???\" You are justifiably shooketh and not sure of what to do next. You just...kinda stand there. \"WHY WOULD YOU STEAL MY BONES DUDE???\" he screams once more.");
		choice1.setText("\"For bone soup\"");
		choice2.setText("\"To enhance my bones\"");
		choice3.setText("\"For the cronch\"");
	}
	
	public void soup() {
		position = "soup";
		mainTextArea.setText("The skeleton looks at you with disgust... \"You know its people like you who are the reason why skeletons are going extinct--just so you can use our bones for soup. You sicken me.\"\n\nThe skeleton's words deal much more emotional damage than any physical damage he could ever inflict on you. You begin to cry so hard. You cry all the moisture out of your body and your eyes start to shrivel up. The rest of you turns to dust and blows away in the wind. If only you had been more sensitive to skeleton issues.\n\nYou are dead.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void enhance() {
		position = "enhance";
		mainTextArea.setText("The skeleton looks horrified at your response. He backs away in terror.\n\nYou say to him, \"with your bones, I can infuse them into my body and I can finally become SKELETON MAN--half MAN, half SKELETON!\"\n\n\"You...monster...\" he whispers.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void cronch() {
		position = "cronch";
		mainTextArea.setText("The skeleton stares at you in complete utter confusion. He figures a freak like you need's to be taken care of, so he stabs you with his dagger and slits your throat--making sure that you won't be cronching anything else ever again.\n\nYou are dead.");
		choice1.setText("===>");
		choice2.setText("===>");
		choice3.setText("===>");
	}
	
	public void end1() {
		position = "end1";
		mainTextArea.setText("Congatulations? You proved yourself to be a \'pretty cool dude\' in front of some awesome skeleton bros and now you get to party with them in this dank cave. Forever. Until you're a skeleton too.\n\nThe end.");
		choice1.setText("");
		choice2.setText("");
		choice3.setText("");
	}
	
	public void end2() {
		position = "end2";
		mainTextArea.setText("You return to your village with gold and precious gems in hand. You become the envy of all the other sad little village boys as you jaunt around with your throngs of bitches fawning over the amazing badass that you are.\n\nThe end.");
		choice1.setText("");
		choice2.setText("");
		choice3.setText("");
	}
	
	public void end3() {
		position = "end3";
		mainTextArea.setText("You successfully steal all his precious bones. You are finally complete. You are the ultimate creature--SKELETON MAN! You return to your village a hero and a legend. You are not the hero your village needs, but the one it deserves.\n\nThe end.");
		choice1.setText("");
		choice2.setText("");
		choice3.setText("");
	}
	
	public class TitleScreenHandler implements ActionListener{
		public void actionPerformed(ActionEvent event) {
			createGameScreen();
		}
	}
	
	public class ChoiceHandler implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			String yourChoice = event.getActionCommand();
			switch(position) {
			case "intro1":
				switch(yourChoice) {
				case "c1": intro2(); break;
				case "c2": intro2(); break;
				case "c3": intro2(); break;
				}
				break;
			case "intro2":
				switch(yourChoice) {
				case "c1": intro3(); break;
				case "c2": intro3(); break;
				case "c3": intro3(); break;
				}
				break;
			case "intro3":
				switch(yourChoice) {
				case "c1": first(); break;
				case "c2": first(); break;
				case "c3": first(); break;
				}
				break;
			case "first":
				switch(yourChoice) {
				case "c1": path1(); break;
				case "c2": path2(); break;
				case "c3": path3(); break;
				}
				break;
			case "path1":
				switch(yourChoice) {
				case "c1": still(); break;
				case "c2": playdead(); break;
				case "c3": run(); break;
				}
				break;
			case "still":
				switch(yourChoice) {
				case "c1": first(); break;
				case "c2": first(); break;
				case "c3": first(); break;
				}
				break;
			case "playdead":
				switch(yourChoice) {
				case "c1": first(); break;
				case "c2": first(); break;
				case "c3": first(); break;
				}
				break;
			case "run":
				switch(yourChoice) {
				case "c1": fork(); break;
				case "c2": fork(); break;
				case "c3": fork(); break;
				}
				break;
			case "fork":
				switch(yourChoice) {
				case "c1": path1Again(); break;
				case "c2": path2(); break;
				case "c3": path3(); break;
				}
				break;
			case "path1Again":
				switch(yourChoice) {
				case "c1": first(); break;
				case "c2": first(); break;
				case "c3": first(); break;
				}
				break;
			case "path2":
				switch(yourChoice) {
				case "c1": cave1(); break;
				case "c2": cave1(); break;
				case "c3": cave1(); break;
				}
				break;
			case "path3":
				switch(yourChoice) {
				case "c1": keepwalking(); break;
				case "c2": inspect(); break;
				case "c3": pickup(); break;
				}
				break;
			case "keepwalking":
				switch(yourChoice) {
				case "c1": first(); break;
				case "c2": first(); break;
				case "c3": first(); break;
				}
				break;
			case "inspect":
				switch(yourChoice) {
				case "c1": keepwalking(); break;
				case "c2": pickup(); break;
				case "c3": breakstick(); break;
				}
				break;
			case "breakstick":
				switch(yourChoice) {
				case "c1": keepwalking(); break;
				case "c2": keepwalking(); break;
				case "c3": keepwalking(); break;
				}
				break;
			case "pickup":
				switch(yourChoice) {
				case "c1": deadend(); break;
				case "c2": arrow(); break;
				case "c3": flipoff(); break;
				}
				break;
			case "arrow":
				switch(yourChoice) {
				case "c1": deadend(); break;
				case "c2": deadend(); break;
				case "c3": deadend(); break;
				}
				break;
			case "flipoff":
				switch(yourChoice) {
				case "c1": deadend(); break;
				case "c2": deadend(); break;
				case "c3": deadend(); break;
				}
				break;
			case "deadend":
				switch(yourChoice) {
				case "c1": path1(); break;
				case "c2": path2(); break;
				case "c3": path3again(); break;
				}
				break;
			case "path3again":
				switch(yourChoice) {
				case "c1": deadend(); break;
				case "c2": deadend(); break;
				case "c3": deadend(); break;
				}
				break;
			case "cave1":
				switch(yourChoice) {
				case "c1": cave2(); break;
				case "c2": cave2(); break;
				case "c3": cave2(); break;
				}
				break;
			case "cave2":
				switch(yourChoice) {
				case "c1": wine(); break;
				case "c2": dagger(); break;
				case "c3": steal(); break;
				}
				break;
			case "wine":
				switch(yourChoice) {
				case "c1": skeleton1(); break;
				case "c2": skeleton1(); break;
				case "c3": skeleton1(); break;
				}
				break;
			case "skeleton1":
				switch(yourChoice) {
				case "c1": fight1(); break;
				case "c2": fight1(); break;
				case "c3": fight1(); break;
				}
				break;
			case "fight1":
				switch(yourChoice) {
				case "c1": drink(); break;
				case "c2": dontdrink(); break;
				case "c3": give(); break;
				}
				break;
			case "drink":
				switch(yourChoice) {
				case "c1": tension(); break;
				case "c2": tension(); break;
				case "c3": tension(); break;
				}
				break;
			case "tension":
				switch(yourChoice) {
				case "c1": party(); break;
				case "c2": party(); break;
				case "c3": party(); break;
				}
				break;
			case "party":
				switch(yourChoice) {
				case "c1": end1(); break;
				case "c2": end1(); break;
				case "c3": end1(); break;
				}
				break;
			case "dontdrink":
				switch(yourChoice) {
				case "c1": whatnow(); break;
				case "c2": whatnow(); break;
				case "c3": whatnow(); break;
				}
				break;
			case "give":
				switch(yourChoice) {
				case "c1": whatnow(); break;
				case "c2": whatnow(); break;
				case "c3": whatnow(); break;
				}
				break;
			case "whatnow":
				switch(yourChoice) {
				case "c1": first(); break;
				case "c2": first(); break;
				case "c3": first(); break;
				}
				break;
			case "dagger":
				switch(yourChoice) {
				case "c1": skeleton2(); break;
				case "c2": skeleton2(); break;
				case "c3": skeleton2(); break;
				}
				break;
			case "skeleton2":
				switch(yourChoice) {
				case "c1": fight2(); break;
				case "c2": fight2(); break;
				case "c3": fight2(); break;
				}
				break;
			case "fight2":
				switch(yourChoice) {
				case "c1": stab(); break;
				case "c2": yourself(); break;
				case "c3": punch(); break;
				}
				break;
			case "stab":
				switch(yourChoice) {
				case "c1": first(); break;
				case "c2": first(); break;
				case "c3": first(); break;
				}
				break;
			case "yourself":
				switch(yourChoice) {
				case "c1": first(); break;
				case "c2": first(); break;
				case "c3": first(); break;
				}
				break;
			case "punch":
				switch(yourChoice) {
				case "c1": end2(); break;
				case "c2": end2(); break;
				case "c3": end2(); break;
				}
				break;
			case "steal":
				switch(yourChoice) {
				case "c1": skeleton3(); break;
				case "c2": skeleton3(); break;
				case "c3": skeleton3(); break;
				}
				break;
			case "skeleton3":
				switch(yourChoice) {
				case "c1": fight3(); break;
				case "c2": fight3(); break;
				case "c3": fight3(); break;
				}
				break;
			case "fight3":
				switch(yourChoice) {
				case "c1": soup(); break;
				case "c2": enhance(); break;
				case "c3": cronch(); break;
				}
				break;
			case "soup":
				switch(yourChoice) {
				case "c1": first(); break;
				case "c2": first(); break;
				case "c3": first(); break;
				}
				break;
			case "enhance":
				switch(yourChoice) {
				case "c1": end3(); break;
				case "c2": end3(); break;
				case "c3": end3(); break;
				}
				break;
			case "cronch":
				switch(yourChoice) {
				case "c1": first(); break;
				case "c2": first(); break;
				case "c3": first(); break;
				}
				break;
			}
		}
	}
}
